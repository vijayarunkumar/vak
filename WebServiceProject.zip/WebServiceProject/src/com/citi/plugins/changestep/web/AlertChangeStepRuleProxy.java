package com.citi.plugins.changestep.web;

public class AlertChangeStepRuleProxy implements com.citi.plugins.changestep.web.AlertChangeStepRule {
  private String _endpoint = null;
  private com.citi.plugins.changestep.web.AlertChangeStepRule alertChangeStepRule = null;
  
  public AlertChangeStepRuleProxy() {
    _initAlertChangeStepRuleProxy();
  }
  
  public AlertChangeStepRuleProxy(String endpoint) {
    _endpoint = endpoint;
    _initAlertChangeStepRuleProxy();
  }
  
  private void _initAlertChangeStepRuleProxy() {
    try {
      alertChangeStepRule = (new com.citi.plugins.changestep.web.AlertChangeStepRuleServiceLocator()).getAlertChangeStepRule();
      if (alertChangeStepRule != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)alertChangeStepRule)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)alertChangeStepRule)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (alertChangeStepRule != null)
      ((javax.xml.rpc.Stub)alertChangeStepRule)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.citi.plugins.changestep.web.AlertChangeStepRule getAlertChangeStepRule() {
    if (alertChangeStepRule == null)
      _initAlertChangeStepRuleProxy();
    return alertChangeStepRule;
  }
  
  public com.citi.plugins.changestep.web.ChangeStepResponse runChangeStepRule(com.citi.plugins.changestep.web.ChangeStepRequest request) throws java.rmi.RemoteException{
    if (alertChangeStepRule == null)
      _initAlertChangeStepRuleProxy();
    return alertChangeStepRule.runChangeStepRule(request);
  }
  
  
}