/**
 * AlertChangeStepRuleService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.citi.plugins.changestep.web;

public interface AlertChangeStepRuleService extends javax.xml.rpc.Service {
    public java.lang.String getAlertChangeStepRuleAddress();

    public com.citi.plugins.changestep.web.AlertChangeStepRule getAlertChangeStepRule() throws javax.xml.rpc.ServiceException;

    public com.citi.plugins.changestep.web.AlertChangeStepRule getAlertChangeStepRule(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
