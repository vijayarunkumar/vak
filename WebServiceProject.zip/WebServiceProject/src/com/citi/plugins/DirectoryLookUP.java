package com.citi.plugins;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.google.gson.Gson;

import oracle.jdbc.pool.OracleDataSource;

/**
 * Title: DirectoryLookUP
 * Description:   Class for LDAP Lookup operation
 * Company: L&T InFotech 
 * @author: va87348
 * @created on: JUN 29 2017
 * @version 
 */
/***********
 * Revision Info************ Update Date Updated By Comment
 **************************/
public class DirectoryLookUP
{
	private static final Logger LOGGER = Logger.getLogger(DirectoryLookUP.class);
	private static URLClassLoader uRLClassLoader = null;

	private DirectoryLookUP()
	{

	}

	/**
	 * Method to load class from jar for LDAP lookup
	 * 
	 * @param paths
	 *            - Path on which the class is to loaded from
	 * @return true if the classes are loaded
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	private static boolean loadClassFromJar(String paths) throws IOException, ClassNotFoundException
	{
		File[] files = new File(paths).listFiles();
		URL[] urls = new URL[files.length];
		for (int i = 0; i < files.length; i++)
		{
			System.out.println("Path :: " + files[i]);
			if (files[i].canRead() && files[i].getName().endsWith(".jar"))
				urls[i] = new URL("jar:file:" + files[i] + "!/");
		}
		uRLClassLoader = new URLClassLoader(urls);
		return true;
	}

	/**
	 * Method to get user details from LDAP
	 * 
	 * @param userID
	 *            - String value of the userid t o fetch details
	 * @param datasource
	 *            - DataSource object
	 * @return string value of the LDAP lookup
	 */
	public static synchronized String getUserDetails(String userID, DataSource datasource)
	{
		System.out.println("getUserDetails :: " + userID);
		String jsonMsg = null;
		try
		{
			if (uRLClassLoader == null)
			{
				String url = getURlFromDB(datasource);
				System.out.println("URL :: " + url);
				File file = new File(url).getCanonicalFile();
				System.out.println("UTILITY JAR LOCATIOn ::: " + file.getAbsolutePath() + File.separator + "ACMUtility.jar");
				loadClassFromJar(file.getAbsolutePath());
			}

			Object entiy;

			Object obj = uRLClassLoader.loadClass("com.citi.aml.ldap.util.LDAPUtil").newInstance();
			Method med = obj.getClass().getMethod("getUserDetails", String.class, DataSource.class);
			entiy = med.invoke(obj, userID, datasource);
			Gson gson = new Gson();
			jsonMsg = gson.toJson(entiy);
			System.out.println("jsonMsg  :: " + jsonMsg);

		} catch (SQLException e)
		{
			System.out.println("SQLException in Class LOADER");
			uRLClassLoader = null;
			LOGGER.error(e.getMessage(), e);
			return null;
		} catch (IOException | ClassNotFoundException | InstantiationException | IllegalAccessException | NoSuchMethodException | SecurityException | IllegalArgumentException
				| InvocationTargetException e)
		{

			System.out.println("IOException in Class LOADER");
			uRLClassLoader = null;
			LOGGER.error(e.getMessage(), e);

		}

		return jsonMsg;

	}

	/**
	 * 
	 * @param datasource
	 *            - DataSource Object
	 * @return String value of the URI to resolve the location of ACM_UTILITY
	 * @throws SQLException
	 */
	private static String getURlFromDB(DataSource datasource) throws SQLException
	{
		String url = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try
		{
			con = datasource.getConnection();

			pstmt = con.prepareStatement("select PARAM_VALUE from ACM_CONFIGURATIONS where PARAM_NAME ='ACM_UTILITY'");
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				url = rs.getString(1);
				System.out.println("URL From DB :: " + url);
				url = url.replace("${system:user.home}", System.getProperty("user.home"));
				url = url.replace("${system:user.dir}", System.getProperty("user.dir"));
				System.out.println("DB URL Changed  :: " + url);
			}

		} catch (SQLException | NullPointerException e)
		{

			LOGGER.error(e.getMessage(), e);
			return "C:\\Users\\va87348\\Desktop\\ACMUtility\\lib";
		} finally
		{
			closeResultSet(rs);
			closeStatement(pstmt);
		}
		return "C:\\Users\\va87348\\Desktop\\ACMUtility\\lib";
	}

	/**
	 * Generic method to close Statement
	 * 
	 * @param st
	 *            - Statement object
	 */
	private static void closeStatement(Statement st)
	{

		try
		{
			if (st != null && !st.isClosed())
			{
				st.close();
			}
		} catch (SQLException e)
		{
			LOGGER.error(e.getMessage(), e);
		}

	}

	private static void closeResultSet(ResultSet resultSet)
	{

		try
		{
			if (resultSet != null)
			{
				resultSet.close();
			}
		} catch (SQLException e)
		{
			LOGGER.error(e.getMessage(), e);
		}

	}

	static private DataSource getLocalDataSource(String url, String userName, String pass)
	{

		OracleDataSource oracleDS = null;

		try
		{
			oracleDS = new OracleDataSource();
			oracleDS.setURL(url);
			oracleDS.setUser(userName);
			oracleDS.setPassword(pass);
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return (DataSource) oracleDS;
	}

	private static DataSource extnDataSource = null;

	static public DataSource getACMExtenDataSource()
	{
		if (extnDataSource == null)
		{
			/*
			 * DatabaseConnector dbConn; try { dbConn = new
			 * DatabaseConnector("jdbc/rcmExtnOraCon"); extnDataSource =
			 * dbConn.getDataSource(); } catch (NamingException e1) {
			 * LOGGER.error(e1); }
			 */
			extnDataSource = getLocalDataSource("jdbc:oracle:thin:@oraasgtd34-scan:8889:NA4AIPD", "na4aipd_was_cstm", "lLBF2H0s");

		}
		System.out.println(" getACMExtenDataSource End :: " + extnDataSource);
		return extnDataSource;
	}

	public static void main(String a[])
	{
		DirectoryLookUP.getUserDetails("va87", getACMExtenDataSource());
	}

}
