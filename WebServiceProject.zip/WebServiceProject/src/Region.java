import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Region {
	private static final String CONTROLFILE = "//release.ctl";
	private static final String REGIONCONTROLFILE = "_release.ctl";
	private static final String SEPERATOR = "line.separator";
	private static Scanner scanner;

	public static void main(String[] args) {
		
		args = new String[]{"C:\\Vijai\\test","APAC","NAM,APAC"};
		try {
			if (args.length > 0) {
				String region = args[1].toUpperCase();
				List<String> validRegion = Arrays.asList(args[2].toUpperCase().split(","));
				String file = args[0] + "//" + region + REGIONCONTROLFILE;
				File obj = new File(file);
				obj.delete();
				File regionControlFile = new File(args[0] + "//" + region+ REGIONCONTROLFILE);
				System.out.println(region + " Region Specific CTL File : "+ regionControlFile.getAbsolutePath());
				File ctrolFile = new File(args[0] + CONTROLFILE);
				scanner = new Scanner(ctrolFile);
				String content = scanner.useDelimiter("//Z").next();
				List<String> splitString = Arrays.asList(content.replaceAll(System.getProperty(SEPERATOR), " ").split(" "));
				BufferedWriter out = new BufferedWriter(new FileWriter(regionControlFile));
				List<String> addedContent = new ArrayList<String>();
				int i=1;
				for (String x : splitString) {
					System.out.println(" CCCC :: " + x);
					if (x.toUpperCase().contains(region) && x.toUpperCase().contains("_")) {
						System.out.println("File Name : " + x);
						out.write(x.toString());
						if(i!=splitString.size()){
							out.newLine();
						}
						out.flush();
						addedContent.add(x);
					}
					String[] xSplit = x.split("_");
					if(!validRegion.contains(xSplit[0].toUpperCase())&&!splitString.contains(region+"_"+x)&&!addedContent.contains(region + "_" + x)){
						System.out.println("File Name : " + x);
						out.write(x.toString());
						if(i!=splitString.size()){
							out.newLine();
						}
						out.flush();
					}
					i++;
				}
				out.close();
			}else{
				System.out.println("Region Specific Build Failed Pass three arguments.. 1}Complete Path for CTL File,2}Region Name,3}ALL valid regions");
			}
		} catch (Exception e) {
			System.out.println("Region Specific build failed : "+ e.getMessage());
		}
	}
}
