package org.vak;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Ser implements Serializable, Cloneable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 13435353423L;

	NonSer nonSer = new NonSer();

	public Ser seralizeMe() throws FileNotFoundException, IOException
	{

		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(new File("C:\\Users\\va87348\\Desktop\\test.vak")));

		out.writeObject(this);
		out.close();
		
		return this;
	}
	
	public Ser seralizeMe2() throws FileNotFoundException, IOException
	{

		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(new File("C:\\Users\\va87348\\Desktop\\test.vak")));

		out.writeObject(this);
		out.close();
		
		return this;
	}

	@Override
	public Object clone() throws CloneNotSupportedException
	{
		
		Ser ser = (Ser) super.clone();

		ser.nonSer = (NonSer) nonSer.clone();
		return ser;
	}
}

class NonSer implements Serializable, Cloneable
{
	@Override
	protected Object clone() throws CloneNotSupportedException
	{
		// TODO Auto-generated method stub
		return super.clone();
	}
}
