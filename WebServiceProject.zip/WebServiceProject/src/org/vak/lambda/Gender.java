package org.vak.lambda;

/**
 * @author MikeW
 */
public enum Gender { MALE, FEMALE }
