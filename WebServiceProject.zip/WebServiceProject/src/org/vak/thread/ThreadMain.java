package org.vak.thread;

public class ThreadMain
{

	public static void main(String[] args) throws InterruptedException
	{

		Thread.UncaughtExceptionHandler h = new Thread.UncaughtExceptionHandler()
		{
			public void uncaughtException(Thread th, Throwable ex)
			{
				System.out.println("Uncaught exception: " + ex);				 
			}
		};

		ThreadTest threadTestOne = new ThreadTest();
		// ThreadTest threadTestTwo = new ThreadTest();

		Thread t1 = new java.lang.Thread(threadTestOne);
		t1.setUncaughtExceptionHandler(h);
		t1.start();
		Thread.sleep(1000);
		threadTestOne.value = 1;
		Thread t2 = new java.lang.Thread(threadTestOne);
		t2.setUncaughtExceptionHandler(h);
		t2.start();		
		Thread.sleep(1000);
		threadTestOne.value = 0;

	}

	static class ThreadTest implements Runnable
	{
		private Object sharedLock = new Object();
		int value = 0;

		@Override
		public void run()
		{
			this.test('s');
		}

		public void test(char t)
		{
			// synchronized (sharedLock)
			{
				try
				{
					if (t == 's')
					{
						System.out.println(Thread.currentThread().getName() + " : Enter Sleep");
						System.out.println("Value :: " + this.value);
						if (this.value == 0)
							Thread.sleep(10000);
						else
						{

							throw new RuntimeException();
						}

						System.out.println(Thread.currentThread().getName() + " : exit Sleep");
					}
				} catch (InterruptedException e)
				{
					e.printStackTrace();
				}

				System.out.println(Thread.currentThread().getName() + " : Exit method");
			}
		}

	}

}
